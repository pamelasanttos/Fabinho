package com.example.calc_pam

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
// Biblioteca de calcular expressão
import net.objecthunter.exp4j.ExpressionBuilder


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Memoria calculadora
        var mr: Double = 0.0

        // É resultado
        var isResult = false

        // Variaveis para calcular mod
        var operadormod = false
        var tempmod1 = 0.0
        var tempmod2 = 0.0


        //Função para calcular fatorial
        fun fatorial(n: Int): Long {
            var result: Long = 1
            for (i in 1..n) {
                result *= i
            }
            return result
        }

        //Imports dos botões
        var historico = findViewById<TextView>(R.id.historico)
        var display = findViewById<TextView>(R.id.display)


        var btndeg = findViewById<Button>(R.id.btndeg)
        var btnMRC = findViewById<Button>(R.id.btnMRC)
        var btnMMenos = findViewById<Button>(R.id.btnMMenos)
        var btnMMais = findViewById<Button>(R.id.btnMMais)
        var btnCE = findViewById<Button>(R.id.btnCE)
        var btnC = findViewById<Button>(R.id.btnC)

        var btnsen = findViewById<Button>(R.id.btnsen)
        var btncos = findViewById<Button>(R.id.btncos)
        var btntan = findViewById<Button>(R.id.btntan)
        var btneuler = findViewById<Button>(R.id.btneuler)

        var btnsenn = findViewById<Button>(R.id.btnsenn)
        var btncosn = findViewById<Button>(R.id.btncosn)
        var btntann = findViewById<Button>(R.id.btntann)
        var btnpi = findViewById<Button>(R.id.btnpi)

        var btnxquadrado = findViewById<Button>(R.id.btnxquadrado)
        var btn1sobrex = findViewById<Button>(R.id.btn1sobrex)
        var btnabs = findViewById<Button>(R.id.btnabs)
        var btnex = findViewById<Button>(R.id.btnex)
        var btnmod = findViewById<Button>(R.id.btnmod)

        var btnraizquadrada = findViewById<Button>(R.id.btnraizquadrada)
        var btnparentesesabrir = findViewById<Button>(R.id.btnparentesesabrir)
        var btnparntesesfechar = findViewById<Button>(R.id.btnparntesesfechar)
        var btnfatorial = findViewById<Button>(R.id.btnfatorial)
        var btnDividir = findViewById<Button>(R.id.btnDividir)

        var btnxy = findViewById<Button>(R.id.btnxy)
        var btn7 = findViewById<Button>(R.id.btn7)
        var btn8 = findViewById<Button>(R.id.btn8)
        var btn9 = findViewById<Button>(R.id.btn9)
        var btnMultiplicar = findViewById<Button>(R.id.btnMultiplicar)

        var btn10x = findViewById<Button>(R.id.btn10x)
        var btn4 = findViewById<Button>(R.id.btn4)
        var btn5 = findViewById<Button>(R.id.btn5)
        var btn6 = findViewById<Button>(R.id.btn6)
        var btnMenos = findViewById<Button>(R.id.btnMenos)

        var btnlog = findViewById<Button>(R.id.btnlog)
        var btn1 = findViewById<Button>(R.id.btn1)
        var btn2 = findViewById<Button>(R.id.btn2)
        var btn3 = findViewById<Button>(R.id.btn3)
        var btnMais = findViewById<Button>(R.id.btnMais)

        var btnln = findViewById<Button>(R.id.btnln)
        var btn0 = findViewById<Button>(R.id.btn0)
        var btnPonto = findViewById<Button>(R.id.btnPonto)
        var btnIgual = findViewById<Button>(R.id.btnIgual)


        // Botoes números
        btn0.setOnClickListener {
            if (display.text.toString() == "0" || isResult == true ) {
                display.text = "0"
                isResult = false
            } else {
                display.text = display.text.toString() + "0"
            }

        }

        btn1.setOnClickListener {
            if (display.text.toString() == "0" || isResult == true) {
                display.text = "1"
                isResult = false
            } else {
                display.text = display.text.toString() + "1"
            }

        }

        btn2.setOnClickListener {
            if (display.text.toString() == "0" || isResult == true) {
                display.text = "2"
                isResult = false
            } else {
                display.text = display.text.toString() + "2"
            }

        }

        btn3.setOnClickListener {
            if (display.text.toString() == "0" || isResult == true) {
                display.text = "3"
                isResult = false
            } else {
                display.text = display.text.toString() + "3"
            }

        }

        btn4.setOnClickListener {
            if (display.text.toString() == "0" || isResult == true) {
                display.text = "4"
                isResult = false
            } else {
                display.text = display.text.toString() + "4"
            }

        }

        btn5.setOnClickListener {
            if (display.text.toString() == "0" || isResult == true) {
                display.text = "5"
                isResult = false
            } else {
                display.text = display.text.toString() + "5"
            }

        }

        btn6.setOnClickListener {
            if (display.text.toString() == "0" || isResult == true) {
                display.text = "6"
                isResult = false
            } else {
                display.text = display.text.toString() + "6"
            }

        }

        btn7.setOnClickListener {
            if (display.text.toString() == "0" || isResult == true) {
                display.text = "7"
                isResult = false
            } else {
                display.text = display.text.toString() + "7"
            }

        }

        btn8.setOnClickListener {
            if (display.text.toString() == "0" || isResult == true) {
                display.text = "8"
                isResult = false
            } else {
                display.text = display.text.toString() + "8"
            }

        }

        btn9.setOnClickListener {
            if (display.text.toString() == "0" || isResult == true) {
                display.text = "9"
                isResult = false
            } else {
                display.text = display.text.toString() + "9"
            }
        }

        btnPonto.setOnClickListener {
            if (!display.text.contains("."))
                display.setText(display.text.toString().plus("."))
        }


        // Botões Limpar
        btnCE.setOnClickListener {
            display.setText("0")
            isResult = false
            historico.text = ""
        }

        btnC.setOnClickListener {

            display.text = display.text.toString().dropLast(1)
            if (display.text == "")
                display.setText("0")

        }


        // Botões Memoria
        btnMRC.setOnClickListener{
            display.setText(mr.toString())
        }

        btnMMais.setOnClickListener {
            mr += display.text.toString().toDouble()
            display.setText("0")
            isResult=true
        }

        btnMMenos.setOnClickListener {
            mr -= display.text.toString().toDouble()
            display.setText("0")
            isResult=true
        }

        //Botões Constantes
        btneuler.setOnClickListener {
            var euler = Math.E

            if (display.text.toString().equals("0") || isResult) {
                display.text = String.format("%.2f", euler)
                display.text = display.text.toString().replace(",", ".")
            } else {
                display.text = String.format("%.2f", euler)
                display.text = display.text.toString().replace(",", ".")
            }
            isResult = true

        }

        btnpi.setOnClickListener {
            var pi = Math.PI

            if (display.text.toString().equals("0") || isResult) {
                display.text = String.format("%.2f", pi)
                display.text = display.text.toString().replace(",", ".")
            } else {
                display.text = String.format("%.2f", pi)
                display.text = display.text.toString().replace(",", ".")
            }

            isResult = true
        }

        // Botões Trigonometria

        btnsen.setOnClickListener {
            var calc = Math.sin(display.text.toString().toDouble())
            display.text= String.format("%.2f", calc).replace(",", ".")
            isResult = true
        }

        btncos.setOnClickListener {
            var calc = Math.cos(display.text.toString().toDouble())
            display.text= String.format("%.2f", calc).replace(",", ".")
            isResult = true
        }

        btntan.setOnClickListener {
            var calc = Math.tan(display.text.toString().toDouble())
            display.text= String.format("%.2f", calc).replace(",", ".")
            isResult = true
        }

        btnsenn.setOnClickListener {
            var calc = Math.asin(display.text.toString().toDouble())
            var calctrat = calc*(180/Math.PI)
            display.text= String.format("%.2f", calctrat).replace(",", ".")
            isResult = true
        }

        btncosn.setOnClickListener {
            var calc = Math.acos(display.text.toString().toDouble())
            var calctrat = calc*(180/Math.PI)
            display.text= String.format("%.2f", calc).replace(",", ".")
            isResult = true
        }

        btntann.setOnClickListener {
            var calc = Math.atan(display.text.toString().toDouble())
            var calctrat = calc*(180/Math.PI)
            display.text= String.format("%.2f", calc).replace(",", ".")
            isResult = true
        }

        // Botão Fatorial
        btnfatorial.setOnClickListener {

            var n = display.text.toString().toInt()
            var resultado = fatorial(n)
            display.text = resultado.toString()
            isResult = true

        }

        // Botão X ao quadrado
        btnxquadrado.setOnClickListener {

            var x = display.text.toString().toDouble()
            var calc = Math.pow(x, 2.0)
            display.text = calc.toString()
            isResult = true

        }

        // Botão Raiz quadrada
        btnraizquadrada.setOnClickListener {

            var x = display.text.toString().toDouble()
            var calc = Math.sqrt(x)
            display.text = calc.toString()
            isResult = true

        }

        // Botão 1 Sobre X
        btn1sobrex.setOnClickListener {
            var x = display.text.toString().toDouble()
            var calc = 1 / x
            display.text = calc.toString()
            isResult = true
        }

        // Botão módulo
        btnabs.setOnClickListener {
            var x = display.text.toString().toDouble()
            var calc = Math.abs(x)
            display.text = calc.toString()
            isResult = true
        }

        // Botão Euler a X
        btnex.setOnClickListener {
            var x = display.text.toString().toDouble()
            var e = Math.E
            var calc = Math.pow(e, x)
            display.text = calc.toString()
            isResult=true
        }

        // Botão potencia base 10
        btn10x.setOnClickListener {
            var x = display.text.toString().toDouble()
            var calc = Math.pow(10.0, x)
            display.text = calc.toString()
            isResult = true
        }

        // Botão log de base natural
        btnln.setOnClickListener {
            var x = display.text.toString().toDouble()
            var calc = Math.log(x)
            display.text = calc.toString()
            isResult = true
        }

        // Botão Log base 10
        btnlog.setOnClickListener {
            var x = display.text.toString().toDouble()
            var calc = Math.log10(x)
            display.text = calc.toString()
            isResult = true
        }

        // Botão Mod
        btnmod.setOnClickListener {
            tempmod1 = display.text.toString().toDouble()
            display.text = "0"
            operadormod = true
        }

        // Botão de operações

        btnMais.setOnClickListener {

            var temp = historico.text.toString()

            if (!historico.text.toString().endsWith("+")) {

                if (temp != "") {
                    historico.setText(temp + "+" + display.text.toString())
                }
                else if (temp == ""){
                    historico.setText(display.text.toString() + "+")
                }
            }

            else if (historico.text.toString().endsWith("+")){

                historico.setText(temp + display.text.toString())

            }

            isResult = true
        }

        btnMenos.setOnClickListener {

            var temp = historico.text.toString()

            if (!historico.text.toString().endsWith("-")) {

                if (temp != "") {
                    historico.setText(temp + "-" + display.text.toString())
                }
                else if (temp == ""){
                    historico.setText(display.text.toString() + "-")
                }
            }

            else if (historico.text.toString().endsWith("-")){

                historico.setText(temp + display.text.toString())

            }

            isResult = true
        }

        btnMultiplicar.setOnClickListener {

            var temp = historico.text.toString()

            if (!historico.text.toString().endsWith("*")) {

                if (temp != "") {
                    historico.setText(temp + "*" + display.text.toString())
                }
                else if (temp == ""){
                    historico.setText(display.text.toString() + "*")
                }
            }

            else if (historico.text.toString().endsWith("*")){

                historico.setText(temp + display.text.toString())

            }

            isResult = true
        }

        btnDividir.setOnClickListener {

            var temp = historico.text.toString()

            if (!historico.text.toString().endsWith("/")) {

                if (temp != "") {
                    historico.setText(temp + "/" + display.text.toString())
                }
                else if (temp == ""){
                    historico.setText(display.text.toString() + "/")
                }
            }

            else if (historico.text.toString().endsWith("/")){

                historico.setText(temp + display.text.toString())

            }

            isResult = true
        }

        // Parenteses
        btnparentesesabrir.setOnClickListener {

            historico.setText(historico.text.toString() + "(")
            isResult = true

        }

        btnparntesesfechar.setOnClickListener {

            historico.setText(historico.text.toString() + ")")
            isResult = true

        }

        //Botão DEG

        btndeg.setOnClickListener {
            if (btndeg.text == "DEG")
                btndeg.text = "RAD"
            else if (btndeg.text == "RAD")
                btndeg.text = "DEG"
        }

        // Botão RESULTADO

        btnIgual.setOnClickListener {
            if (operadormod ==true){
                tempmod2 = display.text.toString().toDouble()
                var calc = tempmod1 % tempmod2

                display.text = calc.toString()
                tempmod1 = 0.0
                tempmod2 = 0.0
                operadormod = false
                isResult = true

            }

            else{
                historico.setText(historico.text.toString() + "+" + display.text.toString())
                var expressao = ExpressionBuilder(historico.text.toString()).build()
                var conta = expressao.evaluate()
                display.setText(conta.toString())
                isResult = true
                historico.setText("")

            }
        }


    }
}